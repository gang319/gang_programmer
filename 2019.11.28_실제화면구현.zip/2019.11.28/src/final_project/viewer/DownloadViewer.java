package final_project.viewer;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

// final_project.viewer.DownloadViewer

public class DownloadViewer extends AbstractView {
	@Value("${upload}")
	private String upload;
	
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		// 1) 모델로 파일정보 가져오기
		String file_name = (String)model.get("downloadFile");
		// 2) 다운로드 할 파일 객체 만들기
		File file = new File(upload + file_name);
		// 3) client에 파일을 전송처리(서버 -> 클라이언트 다운로드가 가능하게 처리)
		//		content type 선언
		response.setContentType("application/download; charset=utf-8");
		// 4) 저장할 파일 길이 지정
		response.setContentLength((int)file.length());
		// 5) 파일명 encoding (utf-8), 공백 +를 ""로
		file_name = URLEncoder.encode(file_name, "utf-8").replaceAll("\\+", " ");
		// 6) 파일 지정	attachment;filename=""
		response.setHeader("Content-Disposition", "attachment;filename=\"" + file_name + "\"");
		// 7) binary 파일로 전송
		response.setHeader("Content-Transfer-Encoding", "binary");
		// 8) stream 파일 클라이언트에 전송
		OutputStream out = response.getOutputStream();
		FileInputStream fis = new FileInputStream(file);
		FileCopyUtils.copy(fis, out);
		// 9) Stream 자원 해제
		out.flush();
		
	}
	/*
		# Viewer 만들기
		1. 공통 AbstractView 상속
		2. 핵심 재정의 메서드 선언
			1) 모델로 정보 가져오기
			2) 필요한 기능 선언
		
		# 파일 다운로드 viewer
			1) 모델로 파일정보 가져오기
			2) 파일 객체 선언
			3) 웹환경에서 다운로드 처리를 위한 content type 선언
				- 정보에 대한 설정
				response.setContentType("application/download; charset=utf-8");
				response.setContentLength((int)file.length());
				fname = URLEncoder.encode(fname, "utf-8").replaceAll("\\+", "");
				response.setHeader("Content-Disposition", "attachment;filename=\"" + fname + "\"");
				response.setHeader("Content-Transfer-Encoding", "binary");
				- 실제 전송된 파일은 stream으로 전송이 된다.
				OutputStream out = response.getOutputStream();
				FileInputStream fis = new FileInputStream(file);
			4) 한글 파일명을 위한 선언: encoding 처리
			5) Stream 처리
				response.getOutputStream() 내용을 파일로 전송
	*/
}
