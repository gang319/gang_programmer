package final_project.controller;

import java.util.ArrayList;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import final_project.dao.ChatDao;

@Controller("chatHandler")
public class ChatHandler extends TextWebSocketHandler {
	@Autowired
	private ChatDao dao;
	
	private ArrayList<WebSocketSession> connectedMember;
	public ChatHandler() {
		connectedMember = new ArrayList<WebSocketSession>();
	}
	private Map<String, WebSocketSession> users = new ConcurrentHashMap();

	// 1. 클라이언트에서 소켓 통신으로 서버와 첫 접속을 했을 때
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		// TODO Auto-generated method stub
		super.afterConnectionEstablished(session);
		System.out.println("접속 성공: " + session.getId());
		// websocket session 정보 추가 등록
		users.put(session.getId(), session);
		// connectedMember.add(session);
		// System.out.println("현재 접속한 client 수: " + users.size());
	}

	// 2. 클라이언트가 서버에 메시지를 전송 시 처리될 내용
	//		서버는 접속하고 있는 모든 클라이언트에 받은 메시지를 push 방식으로 전송을 한다.
	@Override
	public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
		// TODO Auto-generated method stub
		super.handleMessage(session, message);
		System.out.println("받은 message: " + message.getPayload());
		
		for(WebSocketSession s : users.values()) { s.sendMessage(message); }
	}
	
	// 3. 클라이언트가 서버에 접속을 종료 시 처리할 내용
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		// TODO Auto-generated method stub
		super.afterConnectionClosed(session, status);
		System.out.println(session.getId() + "접속 종료");
		users.remove(session.getId());
	}

	// 4. 예외 상황에 대한 분리
	@Override
	public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
		// TODO Auto-generated method stub
		super.handleTransportError(session, exception);
	}
	
}

/*
	# 그룹 채팅 처리
	1. db 구성
		- 채팅할 수 있는 채팅 ID와 그룹명을 설정한다.
		- 조건의 채팅 ID를 넘기면 같은 그룹에 있는 채팅 ID를 가져오게 처리한다.
	2. handleMessage
		for(WebSocketSession s : users.values()) { 에서 dao를 접근하여, 조건으로 같은 그룹에 있는 ID에게만 메시지가 전송될 수 있게 처리
	3. 화면단 처리
		1) 현재 chatting 서버에 로그인한 아이디를 보고 선택하여 db로 그룹이 설정되게 한다. (ajax)
*/