package final_project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.SchedulerService;
import final_project.vo.Scheduler;

@Controller
@RequestMapping("/scheduler.do")
public class SchedulerController {
	@Autowired
	private SchedulerService service;
	
	// http://localhost:7080/a03_team/scheduler.do?method=init
	@RequestMapping(params="method=init")
	public String main() {
		return "WEB-INF\\view\\bs\\scheduler.jsp";
	}
	// http://localhost:7080/a03_team/scheduler.do?method=list
	@RequestMapping(params="method=list")
	public String list(Model d) {
		d.addAttribute("list", service.list());
		return "pageJsonReport";
	}	
	// scheduler.do?method=insAjax
	@RequestMapping(params="method=insAjax")
	public String insAjax(Scheduler ins, Model d) {
		service.insertScheduler(ins);
		System.out.println("등록 일정: "+ins.getTitle());
		return "pageJsonReport";
	}
	// method=updateAjax
	@RequestMapping(params="method=updateAjax")
	public String updateAjax(Scheduler upt, Model d) {
		System.out.println("수정할 일정: "+upt.getTitle());
		service.updateScheduler(upt);
		return "pageJsonReport";
	}
	// method=deleteAjax
	@RequestMapping(params="method=deleteAjax")
	public String deleteAjax(@RequestParam("id") int id, Model d) {
		System.out.println("삭제할 id: "+id);
		service.deleteScheduler(id);
		return "pageJsonReport";
	}
	@RequestMapping(params="method=insert")
	public String insert(
			@RequestParam("title") String title,
			@RequestParam("start") String start, Model d) {
		System.out.println("업무명: "+title);
		System.out.println("시작일: "+start);
		d.addAttribute("scheduler", new Scheduler());
		return "pageJsonReport";
	}
}
