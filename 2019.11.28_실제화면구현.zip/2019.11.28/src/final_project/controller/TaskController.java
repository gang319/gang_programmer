package final_project.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import final_project.service.TaskService;
import final_project.vo.Search;
import final_project.vo.Task;

@Controller
@RequestMapping("/pmsTask.do")
public class TaskController {
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);

	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@Autowired
	private TaskService service;
	
	@RequestMapping(params = "method=task")
	public String task(@ModelAttribute("tsch") Search sch, Model d) {
		d.addAttribute("tlist", service.tlist(sch));
		d.addAttribute("getProject", service.getProject());
		d.addAttribute("getMember", service.getMember());
		
		return "WEB-INF\\view\\bs\\taskList.jsp";
	}
	
	@RequestMapping(params = "method=tasklist")
	public String tlist(@ModelAttribute("tsch") Search sch, Model d) {
		d.addAttribute("tlist", service.tlist(sch));
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=detail")
	public String detail(@RequestParam("task_co") String task_co, Model d) throws Exception  {
		System.out.println("검색 task_co: " + task_co);
		d.addAttribute("task", service.getTask(task_co));
		d.addAttribute("getProject", service.getProject());
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=taskinsert")
	public String insert(@RequestParam(value="task_content", required = false) String task_content, 
			Task t, Model d) throws Exception{
		System.out.println("업무 등록: "+t.getTask_name());
		// System.out.println("file: " + t.getReport().getOriginalFilename());
		
		service.insertTask(t);
		Task ta = new Task();
		d.addAttribute("task", ta);
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=taskupdate")
	public String update(Task upt, Model d) throws Exception{
		System.out.println("업무코드: " + upt.getTask_co());
		System.out.println("프로젝트명: " + upt.getPro_title());
		System.out.println("이름: " + upt.getName());
		System.out.println("우선순위: " + upt.getTask_rank());
		System.out.println("업무명: " + upt.getTask_name());
		System.out.println("분류: " + upt.getSort());
		System.out.println("프로세스: " + upt.getPro_state());
		System.out.println("프로세스순서: " + upt.getPro_statenum());
		System.out.println("난이도: " + upt.getDifficulty());
		System.out.println("시작일: " + upt.getTask_sdate());
		System.out.println("파일1: " + upt.getReport());
		System.out.println("파일2: " + upt.getTask_file_name());
		System.out.println("파일3: " + upt.getTask_file_content());
		
		service.updateTask(upt);
		d.addAttribute("succ", service.getTask(upt.getTask_co()));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=download")
	public String download(@RequestParam("task_file_name") String task_file_name, Model m) {
		m.addAttribute("downloadFile", task_file_name);
		
		return "downloadViewer";
	}
}
