package final_project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ChattingController {
	// http://localhost:7080/web_spring/chat.do
	@RequestMapping("/chat.do")
	public String chat() {
		return "WEB-INF\\view\\bs\\chat.jsp";
	}

}

/*
	# 스프링에서 web socket을 통한 채팅 처리
	1. 초기 화면 controller 선언
		1) 채팅하는 화면 구현
	2. socket 통신할 수 있는 handler 클래스 선언
		1) 채팅 메시지를 서버와 클라이언트단 연결
		2) 메시지를 클라이언트에서 받아, 접속하고 있는 클라이언트에 전송처리
	3. 컨테이너 설정(dispatcher-servlet.xml)
		1) handler를 소켓통신을 할 수 있게끔 설정
		2) 위 선언할 handler 등록
	4. 초기 화면에서 호출한 View 단에서 handler와 상호작용한 js단 처리
*/