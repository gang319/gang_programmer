package final_project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.SettingService;
import final_project.vo.Member;
import final_project.vo.Search;

//http://localhost:7080/final_project/pmsset.do?method=person
//http://localhost:7080/final_project/pmsset.do?method=detail
//http://localhost:7080/a03_team/pmsset.do?method=person
//http://192.168.0.47:7080/a03_team/pmsset.do?method=person
//http://192.168.0.47:7080/a03_team/pmsset.do?method=member
//http://localhost:7080/a03_team/issue.do?method=list
@Controller
@RequestMapping("/pmsset.do")
public class SettingController {
	@Autowired
	private SettingService service;
	
	//담당자 고객 리스트  /// /pmsset.do?method=person
	@RequestMapping(params = "method=person")
	public String setpm(@ModelAttribute("psch") Search sch,HttpSession session, Model d) {
		
		System.out.println("(controller)현재 클릭한 page 번호 : " + sch.getCurPage());
		System.out.println("건수: " + service.elist(sch).size());		
		
		d.addAttribute("elist",service.elist(sch));		
		 
		return "WEB-INF\\view\\bs\\setting.jsp";		
	}
	
	//담당자 리스트
	@RequestMapping(params="method=member")
	public String member(@ModelAttribute("csch") Search csch, Model d) {
		System.out.println("(controller)현재 클릭한 page 번호 : " + csch.getCurPage());
		System.out.println("건수: " + service.clist(csch).size());
		
		d.addAttribute("clist",service.clist(csch));
		
		return "WEB-INF\\view\\bs\\setting_mem.jsp";
	}
	
	
	//PM 추가 insert
	@RequestMapping(params="method=insert")
	public String insert(Member insert,Model d, Model a)throws Exception{
		System.out.println("등록:"+ insert.getId());
		
		System.out.println("발송한 메일 아이디: " + insert.getId());		
		
		service.sendMail(insert);
		
		service.insertMember(insert);
		
		Member m = new Member();
		
		d.addAttribute("member",m);
		
		/*
		if(insert.getId()!=null) {
			a.addAttribute("isSuccess",);			
		}	
		*/
		System.out.println("id: " + insert.getId());		
		
		return "pageJsonReport";
	
	}
	
	//담당자 추가 insert
	@RequestMapping(params="method=meinsert")
	public String meinsert(Member insert,Model d)throws Exception{
		System.out.println("등록:"+insert.getId());
		System.out.println("발송한 메일 아이디" + insert.getId());
		
		service.sendMail(insert);	
		
		service.insert1Member(insert);		
		
		Member m = new Member();		
		
		d.addAttribute("member",m);		
		
		/*
		if(insert.getId()!=null) {
			d.addAttribute("isSuccess",service.sendMail(insert));			
		}	
		*/
		System.out.println("id: " + insert.getId());
		//"redirect:/pmsset.do?method=person";
		
		return "pageJsonReport";
	}
	
	//담당자 수정 detail
	@RequestMapping(params="method=detail")
	public String detail(@RequestParam("id")String id,Model d) throws Exception{
		System.out.println("아이디: "+id);
		
		d.addAttribute("member",service.getMember(id));		
		return "pageJsonReport";
	}
	
	//담당자 수정 update
	@RequestMapping(params="method=update")
	public String update(Member upt,Model d) throws Exception {
		service.updateMember(upt);		
		d.addAttribute("member",service.getMember(upt.getId()));
		
		return "pageJsonReport";
	}
	
	//담당자 삭제 delete
	@RequestMapping(params="method=delete")
	public String delete(@RequestParam("id") String id,Model d) throws Exception {
		
		Member m = new Member();
		System.out.println("삭제: " +m.getId());		
		m.setId("삭제성공");
		service.delMember(id);
		d.addAttribute("member",m);
		
		return "pageJsonReport";
	}
	
	//ADMIN 권한설정 update
	@RequestMapping(params="method=adupdate")
	public String adMember(Member ad,Model d)throws Exception{
		service.adMember(ad);
		d.addAttribute("member",service.getMember(ad.getId()));
		
		return "pageJsonReport";
	}
	
	//PM 권한설정 update
	@RequestMapping(params="method=pmupdate")
	public String pmMember(Member pm,Model d)throws Exception{
		service.pmMember(pm);
		d.addAttribute(pm);
		d.addAttribute("member",service.getMember(pm.getId()));
		
		return "pageJsonReport";		
	}
	
	/*pm 이름별보기 
	@RequestMapping(params = "method=pmname")
	public String pmname(@ModelAttribute("pmname") Search pmname, Model d) {		
		System.out.println("pmname (controller)현재 클릭한 page 번호 : " + pmname.getCurPage());
		System.out.println("pmname 건수: " + service.pmname(pmname).size());	
		
		d.addAttribute("pmname",service.pmname(pmname));		
		 
		return "pageJsonReport";		
	}
	*/
	
}