package final_project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import final_project.service.IssueService;
import final_project.service.MemberService;
import final_project.service.ProjectService;
import final_project.service.TaskService;
import final_project.vo.Member;
import final_project.vo.Project;
import final_project.vo.Search;

//http://localhost:7080/a03_team/pms.do?method=loginForm
@Controller
@RequestMapping("/pms.do")
public class MemberController {
	@Autowired
	private MemberService service;
	@Autowired
	private ProjectService service4;
	
	@RequestMapping(params = "method=loginForm")
	public String loginForm() {
		return "WEB-INF\\view\\bs\\loginMain.jsp";
	}
	
	@RequestMapping(params = "method=login")
	public String login(Member mem, HttpSession session, Model m) {
		if(service.loginChk(mem)) {
			session.setAttribute("mem", mem);
			
			return "redirect:/pms.do?method=main";
			
		}else {
			return "redirect:/pms.do?method=loginForm";
			
		}
		
	}
	
	@RequestMapping(params = "method=main")
	public String main(HttpSession session, Model d) {
		Member m = (Member) session.getAttribute("mem");
		
		if(m.getId() == null) {
			return "redirect:/pms.do?method=loginForm";
			
		}else {
			d.addAttribute("login", service.memlogin(m));
			return "WEB-INF\\view\\bs\\index.jsp";
		}
	}
	
	@RequestMapping(params = "method=dashboard")
	public String dashboard(@ModelAttribute("isch") Search isch, 
			@ModelAttribute("tsch") Search tsch, @ModelAttribute("psch") Search psch, Model m) {
		m.addAttribute("issueList", service.issueList(isch));
		m.addAttribute("tlist", service.tlist(tsch));
		
		m.addAttribute("sts_num1", service4.sts_num1());
		m.addAttribute("sts_num2", service4.sts_num2());
		m.addAttribute("sts_num3", service4.sts_num3());
		m.addAttribute("sts_num4", service4.sts_num4());
		m.addAttribute("sts_num5", service4.sts_num5());
		m.addAttribute("sts_num6", service4.sts_num6());
		m.addAttribute("sts_num7", service4.sts_num7());
		
		return "WEB-INF\\view\\bs\\dashBoard.jsp";
	}
	
	@RequestMapping(params = "method=logout")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "redirect:/pms.do?method=loginForm";
	}

}
