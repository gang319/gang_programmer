package final_project.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.MyWorkService;
import final_project.service.TaskService;
import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;

@Controller
@RequestMapping("/mywork.do")
public class MyWorkContoller {
	@Autowired
	private MyWorkService service;
	@Autowired
	private TaskService service2;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);

	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@RequestMapping(params = "method=main")
	public String main(Project p, Task t, Issue i, Model m) {
		System.out.println("프로젝트 타이틀: " + p.getPro_title());
		System.out.println("업무명: " + t.getTask_name());
		System.out.println("이슈명: " + i.getTitle());
		
		m.addAttribute("myproject", service.getProject(p));
		m.addAttribute("mytask", service.getTask(t));
		m.addAttribute("myissue", service.getIssue(i));
		m.addAttribute("getProject", service2.getProject());
		
		return "WEB-INF\\view\\bs\\myWork.jsp";
	}
	
	@RequestMapping(params = "method=proDetail")
	public String proDetail(@RequestParam("pro_co") String pro_co, Model m) {
		System.out.println("선택한 프로젝트 : " + pro_co);
		m.addAttribute("proDet", service.getProjectDet(pro_co));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=taskDetail")
	public String taskDetail(@RequestParam("task_co") String task_co, Model m) {
		System.out.println("선택한 업무 : " + task_co);
		m.addAttribute("taskDet", service.getTaskDet(task_co));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=proUpt")
	public String proUpt(Project p, Model m) {
		System.out.println("수정 project: " + p.getPro_title());
		
		service.updateProject(p);
		m.addAttribute("succ", "upt");
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=taskUpt")
	public String taskUpt(Task t, Model m) {
		System.out.println("수정 task: " + t.getTask_name());
		
		service.updateTask(t);
		m.addAttribute("succ", "upt");
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=download")
	public String download(@RequestParam("task_file_name") String task_file_name, Model m) {
		m.addAttribute("downloadFile", task_file_name);
		
		return "downloadViewer";
	}

}
