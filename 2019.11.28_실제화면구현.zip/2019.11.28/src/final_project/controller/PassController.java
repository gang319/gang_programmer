package final_project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import final_project.service.PassService;
import final_project.vo.Member;

//http://localhost:7080/a03_team/pass.do?method=pass
@Controller
@RequestMapping("/pass.do")
public class PassController {
	@Autowired
	private PassService service;
	
	@RequestMapping(params="method=pass")
	public String pass() {		
		return "WEB-INF\\view\\bs\\password.jsp";
	}
	
	@RequestMapping(params="method=find")
	public String find(Member p,Model d)throws Exception{
		System.out.println("발송한 메일 아이디"+ p.getId());
		
		service.sendMail(p);
		service.pass(m);
		
		Member m = new Member();
		
		d.addAttribute("member",p);
		
		System.out.println("id: " + p.getId());
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=chk")
	public String chk(Member mem, HttpSession session, Model m) {
		if(service.passChk(mem)) {
			session.setAttribute("m", m);
			
			return "redirect:/pass.do?method=main";
		}else {
			
			return "redirect:/pass.do?method=loginForm";
		}
	}
	
	@RequestMapping(params="method=main")
	public String main(HttpSession session, Model d) {
		Member m = (Member) session.getAttribute("mem");
		
		if(m.getId() == null) {
			return "redirect:/pass.do?method=pass";
		}else {
			d.addAttribute("pass",service.passChk(m));
			return "redirect:/pass.do?method=find";
		}
	}
	
}
