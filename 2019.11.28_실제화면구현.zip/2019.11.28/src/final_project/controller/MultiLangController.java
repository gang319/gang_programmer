package final_project.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.LocaleResolver;

@Controller
@RequestMapping("/multilang.do")
public class MultiLangController {
	// 다국어 처리 LocaleResolver 선언
	@Autowired(required=false)
	private LocaleResolver localeResolver;
	
	// 다국어 처리 화면 loginForm
	@RequestMapping(params="method=init")
	public String show() {
		return "WEB-INF\\view\\bs\\loginMain.jsp";
	}
	@RequestMapping(params="method=lang")
	public String lang(@RequestParam("lang") String lang,
						HttpServletRequest request,
						HttpServletResponse response) {
		System.out.println("선택 언어:"+lang);
		localeResolver.setLocale(request, response, new Locale(lang));
		return "WEB-INF\\view\\bs\\loginMain.jsp";
	}
}
