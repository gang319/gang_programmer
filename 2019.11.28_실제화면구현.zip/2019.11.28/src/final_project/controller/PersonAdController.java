package final_project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import final_project.service.PersonAdService;
import final_project.vo.Member;

//http://localhost:7080/a03_team/perad.do?method=admin
@Controller
@RequestMapping("/perad.do")
public class PersonAdController {
	/*
	@Autowired
	private PersonAdService service;
	
	1. 초기화면 호출
	@RequestMapping(params="method=admin")
	public String perad(Member mem, HttpSession session, Model m) {
		session.setAttribute("mem", mem);
		
		return "WEB-INF\\view\\bs\\set-admin.jsp";
	}
	
	@RequestMapping(params="method=person")
	public String perad(HttpSession session, Model d) {
		Member m = (Member) session.getAttribute("mem");
		
		d.addAttribute("login",service.adperson(m));
		
		return "WEB-INF\\view\\bs\\set-admin.jsp";
	}
	*/
}
