package final_project.controller;

import java.beans.PropertyEditorSupport;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import final_project.service.IssueService;
import final_project.vo.Issue;
import final_project.vo.Search;

@Controller
@RequestMapping("/issue.do")
// http://localhost:7080/final_project/issue.do
public class IssueController {
	@Autowired
	private IssueService service;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);

	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	
	@RequestMapping(params = "method=list")
	public String list(@ModelAttribute("isch") Search sch, Model m) {
		System.out.println("(controller)현재 클릭한 page 번호: " + sch.getCurPage());
		System.out.println("건수: " + service.issueList(sch).size());
		
		m.addAttribute("issueList", service.issueList(sch));
		m.addAttribute("getM", service.getManager());
		
		return "WEB-INF\\view\\bs\\issueBoard.jsp";
	}
	
	/*
	 * @RequestMapping(params = "method=list") public String list(Issue sch, Model
	 * m) { m.addAttribute("issueList", service.issueList(sch));
	 * 
	 * return "WEB-INF\\view\\bs\\issueBoard.jsp"; }
	 */
	
	@RequestMapping(params = "method=detail")
	public String detail(@RequestParam("issue_co") String issue_co, Model m) throws Exception {
		System.out.println("번호: " + issue_co);
		
		m.addAttribute("issue", service.getIssue(issue_co));
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=insert")
	public String insert(Issue ins, Model m) {
		MultipartFile report = ins.getReport();
		
		service.insertIssue(ins);
		Issue i = new Issue();
		i.setTitle("이슈 등록이 완료되었습니다.");
		m.addAttribute("issue", i);
		
		System.out.println("title: " + ins.getTitle());
		System.out.println("file: " + report.getOriginalFilename());
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=insertref")
	public String insertref(Issue ins, Model m) {
		System.out.println("title: " + ins.getTitle());
		System.out.println("file: " + ins.getReport().getOriginalFilename());
		
		service.insertRef(ins);
		Issue i = new Issue();
		i.setTitle("이슈 리플 등록이 완료되었습니다.");
		m.addAttribute("issue", i);
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=update")
	public String update(Issue upt, Model m) throws Exception {
		service.updateIssue(upt);
		m.addAttribute("issue", service.getIssue(upt.getIssue_co()));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=updateref")
	public String updateref(Issue upt, Model m) throws Exception {
		service.updateRef(upt);
		m.addAttribute("issue", service.getIssue(upt.getIssue_co()));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=success")
	public String success(@RequestParam("issue_co") String issue_co, Model m) throws Exception {
		service.success(issue_co);
		Issue i = new Issue();
		i.setTitle("이슈 처리 완료되었습니다.");
		m.addAttribute("issue", i);
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=delete")
	public String delete(@RequestParam("issue_co") String issue_co, Model m) throws Exception {
		service.deleteIssue(issue_co);
		Issue i = new Issue();
		i.setTitle("이슈 내용을 삭제하였습니다.");
		m.addAttribute("issue", i);
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params = "method=download")
	public String download(@RequestParam("file_name") String file_name, Model m) {
		m.addAttribute("downloadFile", file_name);
		
		return "downloadViewer";
	}

}
