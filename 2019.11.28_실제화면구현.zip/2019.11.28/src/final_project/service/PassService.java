package final_project.service;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

//final_project.service.PassService
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import final_project.dao.PassDao;
import final_project.vo.Member;

@Service
public class PassService {
	@Autowired
	private PassDao dao;
	
	public Member pass(Member p) {
		return dao.pass(p);
	}
	
	public boolean passChk(Member m) {
		Member p = dao.pass(m);
		
		if(p == null) {
			return false;
		}else {
			String idChk = p.getId();
			if(idChk.equals(m.getId())) {
				return true;
			}else {
				return false;
			}
		}
	}
	
	
	//mail
	//1.container에 있는 mail호출
	@Autowired
	private JavaMailSender mailSender;
	
	//2.메일 전송처리
	public boolean sendMail(Member email,Member p) {
		boolean isSuccess=true;
		// 1)전송할 내용을 처리하는 MimeMessage객체 생성
		MimeMessage msg = mailSender.createMimeMessage();
		
		try {
			// 2) 발신자 지정
			msg.setFrom(new InternetAddress(email.getSender()));
			// 3) 수신자 지정.
			msg.setRecipient(RecipientType.TO, new InternetAddress(p.getId()));
			// 4) 제목 지정.
			msg.setSubject("PMS 찾으신 비밀번호를 알려드립니다.");
			// 5) 내용 지정.			
			msg.setText("아이디와 비밀번호를 알려드립니다." +
						"\n 아이디:" + email.getId() + 
						"\n 비밀번호:" + email.getPass() + 
						"\n http://192.168.0.40:7080/a03_team/pms.do?method=loginForm" + 
						"\n PMS 사이트에 들어오셔서 아이디와 비밀번호로 로그인하면 할 수 있습니다.");					
			// 6) 발송 처리..
			mailSender.send(msg);
			
			// 발송 정상 여부 설정 
			isSuccess =true;
			// 7) 예외처리..			
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("예외:"+e.getMessage());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("예외:"+e.getMessage());
		} catch(Exception e) {
			System.out.println("예외:"+e.getMessage());
		}
		
		return isSuccess;
	}
	
}
