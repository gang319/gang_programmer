package final_project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

import final_project.dao.GanttDao;
import final_project.vo.Assigs;
import final_project.vo.Gantt;
import final_project.vo.Resources;
import final_project.vo.Tasks;

@Service
public class GanttService {
	@Autowired
	private GanttDao dao;
	
	public Gantt glist(long pro_co){
		Gantt gt = dao.glist(pro_co);
		gt.setRoles(dao.rolist());
		gt.setResources(dao.relist());
		gt.setDeletedTaskIds(dao.dlist(pro_co));
		ArrayList<Tasks> t1 = dao.tlist(gt.getPro_co());
		
		for(Tasks t: t1) {
			t.setAssigs(dao.getAssigs(t.getId(), t.getPro_co()));
		}
		
		gt.setTasks(t1);
		
		return gt;
	}
	
	public ArrayList<Gantt> getproco() {
		return dao.getproco();
	}
	
	Gson gson = new Gson();
	
	public void jsonToVo(String prj) {
		
		Gantt gt = gson.fromJson(prj, Gantt.class);
		
		long Gpro_co = gt.getTasks().get(0).getPro_co();
		
		if(Gpro_co==0) {
			
			dao.insertGantt();
			System.out.println("새로운 프로젝트 등록");
			
			ArrayList<Tasks> tasklist = gt.getTasks();
			for(int i=0;i<tasklist.size();i++) {
				
				dao.insertNewTasks(tasklist.get(i));
				ArrayList<Assigs> assigslist = tasklist.get(i).getAssigs();
				for(int j=0;j<assigslist.size();j++) {
					assigslist.get(j).setTid(tasklist.get(i).getId());
					dao.insertNewAssigs(assigslist.get(j));
					System.out.println("[Assigs] 새로 추가된 정보의 Id값 : "+assigslist.get(j).getId());
				}
				
				System.out.println("[Tasks] 새로 추가된 정보의 Name값 : "+tasklist.get(i).getId());
			}
			
			dao.uptpname(dao.getTproco());
			System.out.println(dao.getTproco()+"의 Pname 등록됨");

		} else {
			
			System.out.println(Gpro_co+"의 기존  데이터 변경 시작");

			dao.deleteResources();
			System.out.println("resources 기존 데이터 삭제");
			
			dao.deleteDeletedId(Gpro_co);
			System.out.println("deleteDeletedId 기존 데이터 삭제");
			
			dao.deleteAssigs(Gpro_co);
			System.out.println("assigs 기존 데이터 삭제");
			
			dao.deleteTasks(Gpro_co);
			System.out.println("tasks 기존 데이터 삭제");
			
			
			ArrayList<Resources> rlist = gt.getResources(); 
			for(int i=0;i<rlist.size();i++) { 
				dao.insertNormalResources(rlist.get(i));
				System.out.println("resources 변경된 정보 등록"+(i+1)); 
			}
			
			
			ArrayList<Tasks> tlist = gt.getTasks();
			for(int i=0;i<tlist.size();i++) {
				
				tlist.get(i).setPro_co(Gpro_co);
				
				  dao.insertNormalTasks(tlist.get(i));
				  System.out.println("tasks 변경된 정보 등록"+(i+1));
				  
				  ArrayList<Assigs> alist = tlist.get(i).getAssigs(); 
				  for(int j=0;j<alist.size();j++) { 
					  alist.get(j).setPro_co(Gpro_co);
					  alist.get(j).setTid(tlist.get(i).getId());
					  dao.insertNormalAssigs(alist.get(j)); 
					  System.out.println("assigs 변경된 정보 등록");
				  }
				 
			}
			
			System.out.println(Gpro_co+"의 정보 변경 완료");
		}
		
	}
	
	public void deleteProject(String prj) {
		
		Gantt gt = gson.fromJson(prj, Gantt.class);
		
		long del = gt.getTasks().get(0).getPro_co();
		
		System.out.println("삭제 프로젝트 번호"+del);
		
		dao.deleteGantt(del);
		System.out.println("Gantt 테이블 삭제");
		dao.deleteDeletedId(del);
		System.out.println("DeletedTaskId 테이블 삭제");
		dao.deleteAssigs(del);
		System.out.println("Assigs 테이블 삭제");
		dao.deleteTasks(del);
		System.out.println("Tasks 테이블 삭제");
		
		System.out.println("프로젝트 번호 "+del+"의 데이터가 모두 삭제되었음");
	}
}
