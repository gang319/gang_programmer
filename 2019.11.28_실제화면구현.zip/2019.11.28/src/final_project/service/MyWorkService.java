package final_project.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import final_project.dao.MyWorkDao;
import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;
import final_project.vo.Task_File;

@Service
public class MyWorkService {
	@Autowired
	private MyWorkDao dao;
	
	public ArrayList<Project> getProject(Project sch) {
		return dao.getProject(sch);
	}
	
	public ArrayList<Task> getTask(Task sch) {
		return dao.getTask(sch);
	}
	
	public ArrayList<Issue> getIssue(Issue sch) {
		return dao.getIssue(sch);
	}
	
	public Project getProjectDet(String pro_co) {
		return dao.getProjectDet(pro_co);
	}
	
	public Task getTaskDet(String task_co) {
		Task t = dao.getTaskDet(task_co);
		t.setTask_file_name("");
		if(dao.getFile(task_co) != null) {
			t.setTask_file_name(dao.getFile(task_co).getTask_file_name());
		}
		
		return t;
	}
	
	public void updateProject(Project upt) {
		dao.updateProject(upt);
	}
	
	@Value("${upload}")
	private String upload;
	@Value("${tmpupload}")
	private String tmpupload;
	
	public void updateTask(Task upt) {
		String task_file_name = upload(upt);
		
		// 수정에서 파일을 업로드한 데이터가 있을 때,
		if(task_file_name != null && !task_file_name.equals("")) {
			// DB에서 파일 정보 추가/수정
			Task_File tf = new Task_File();
			tf.setTask_file_co(upt.getTask_co());
			tf.setTask_file_name(task_file_name);
			tf.setTask_file_content(upt.getTask_file_content());
			
			dao.updateFile(tf);
		}
		
		dao.updateTask(upt);
	}
	
	// 파일 업로드 부분 기능 메서드로 공통으로 선언
	private String upload(Task t) {
		// 파일 이름 가져오기
		MultipartFile report = t.getReport();
		String task_file_name = report.getOriginalFilename();
				
		// File 객체 생성하여 처리하기
		File tmpFile = new File(tmpupload + task_file_name);
		File file = new File(upload + task_file_name);
				
		// 요청 객체로 실제 파일 객체 변환하기
			try {
				if(task_file_name != null && !task_file_name.equals("")) {
					report.transferTo(tmpFile);
					// 임시 위치에서 웹서버에 지정 폴더 복사하기
					Files.copy(tmpFile.toPath(), file.toPath(), 
							StandardCopyOption.REPLACE_EXISTING);
					System.out.println("파일 업로드 성공");
				}
						
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
						
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("파일 업로드 시 에러 발생");
						
			}
					
			return task_file_name;
	}

}
