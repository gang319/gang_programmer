package final_project.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.ChatDao;
import final_project.vo.Chat;
import final_project.vo.Message;

@Service
public class ChatService {
	@Autowired
	private ChatDao dao;
	
	public void createRoom(Chat ins) {
		dao.createRoom(ins);
	}
	
	public Chat isRoom(Chat c) {
		return dao.isRoom(c);
	}
	
	public void insertMsg(Message ins) {
		dao.insertMsg(ins);
	}
	
	public String getMember(Chat c) {
		return dao.getMember(c);
	}
	
	public String getName(String str) {
		return dao.getName(str);
	}
	
	public ArrayList<Message> getMessageList(String str) {
		return dao.getMessageList(str);
	}
	
	public ArrayList<Chat> getRoomList(String str) {
		return dao.getRoomList(str);
	}
	
	public Message getRecentMessage(String str) {
		return dao.getRecentMessage(str);
	}

	public void updateReadTime(String name) {
		dao.updateReadTime(name);
	}

}
