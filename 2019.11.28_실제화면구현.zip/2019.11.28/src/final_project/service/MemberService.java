package final_project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.MemberDao;
import final_project.vo.Issue;
import final_project.vo.Member;
import final_project.vo.Search;
import final_project.vo.Task;

@Service
public class MemberService {
	@Autowired
	private MemberDao dao;
	
	public Member memlogin(Member m) {
		return dao.memlogin(m);
	}
	
	public boolean loginChk(Member m) {
		Member mem = dao.memlogin(m);
		
		if(mem == null) {
			return false;
		}else {
			String pastschk = mem.getPass();
			if(pastschk.equals(m.getPass())) {
				return true;
			}else {
				return false;
			}
		}
	}
	
	public ArrayList<Issue> issueList(Search isch) { 
		// 데이터 총 건수 처리
		isch.setCount(dao.getIsCount(isch));
		
		// 화면에 한번에 보여줄 데이터 수 
		if(isch.getPageSize() == 0) { isch.setPageSize(10); }
		
		// 총 페이지 수 처리
		int pgCnt = (int)Math.ceil(isch.getCount() / (double)isch.getPageSize());
		isch.setPageCount(pgCnt == 0 ? 1 : pgCnt);
		
		// 현재 클릭한 페이지 수 설정, 초기값 1
		if(isch.getCurPage() == 0) { isch.setCurPage(1); }
		
		// next 클릭시, 전체 페이지 수를 넘지 않게 처리
		if(isch.getCurPage() > isch.getPageCount()) {
			isch.setCurPage(isch.getPageCount()); 
		}
		
		System.out.println("현재 클릭한 page 번호: " + isch.getCurPage());
		
		// 현재 클릭한 페이지 번호를 통해서 시작 번호와 마지막 번호를 전송처리 
		isch.setStart((isch.getCurPage() - 1) * isch.getPageSize() + 1);
		isch.setEnd(isch.getCurPage() * isch.getPageSize());
		
		System.out.println("시작번호: " + isch.getStart());
		System.out.println("마지막번호: " + isch.getEnd());
		
		// 초기 블록값 설정
		isch.setBlockSize(5);
		// block 설정
		int blocknum = (int)Math.ceil(isch.getCurPage() / (double)isch.getBlockSize());
		int endBlock = blocknum * isch.getBlockSize();
		isch.setEndBlock(endBlock > isch.getPageCount() ? isch.getPageCount() : endBlock);
		isch.setStartBlock((blocknum - 1) * isch.getBlockSize() + 1);
		
		return dao.issueList(isch);
	}
	
	public ArrayList<Task> tlist(Search tsch){
		// 데이터 총 건수 처리
		tsch.setCount(dao.getTasCount(tsch));
						
		// 화면에 한번에 보여줄 데이터 수 
		if(tsch.getPageSize() == 0) { tsch.setPageSize(6); }
						
		// 총 페이지 수 처리
		int pgCnt = (int)Math.ceil(tsch.getCount() / (double)tsch.getPageSize());
		tsch.setPageCount(pgCnt == 0 ? 1 : pgCnt);
						
		// 현재 클릭한 페이지 수 설정, 초기값 1
		if(tsch.getCurPage() == 0) { tsch.setCurPage(1); }
						
		// next 클릭시, 전체 페이지 수를 넘지 않게 처리
		if(tsch.getCurPage() > tsch.getPageCount()) {
			tsch.setCurPage(tsch.getPageCount()); 
		}
						
		// 현재 클릭한 페이지 번호를 통해서 시작 번호와 마지막 번호를 전송처리 
		tsch.setStart((tsch.getCurPage() - 1) * tsch.getPageSize() + 1);
		tsch.setEnd(tsch.getCurPage() * tsch.getPageSize());
						
		// 초기 블록값 설정
		tsch.setBlockSize(5);
		// block 설정
		int blocknum = (int)Math.ceil(tsch.getCurPage() / (double)tsch.getBlockSize());
		int endBlock = blocknum * tsch.getBlockSize();
		tsch.setEndBlock(endBlock > tsch.getPageCount() ? tsch.getPageCount() : endBlock);
		tsch.setStartBlock((blocknum - 1) * tsch.getBlockSize() + 1);
		
		return dao.tlist(tsch);
	}

}
