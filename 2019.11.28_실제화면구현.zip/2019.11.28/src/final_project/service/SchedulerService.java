package final_project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.schedulerDao;
import final_project.vo.Scheduler;

@Service
public class SchedulerService {
	@Autowired
	private schedulerDao dao;
	public ArrayList<Scheduler> list(){
		return dao.list();
	}
	public void insertScheduler(Scheduler ins) {
		dao.insertScheduler(ins);
	}
	public void updateScheduler(Scheduler upt) {
		dao.updateScheduler(upt);
	};
	public void deleteScheduler(int id) {
		dao.deleteScheduler(id);
	}
}
