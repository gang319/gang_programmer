package final_project.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import final_project.dao.TaskDao;
import final_project.vo.Member;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;
import final_project.vo.Task_File;

@Service
public class TaskService {
	@Autowired
	private TaskDao dao;
	
	public ArrayList<Task> tlist(Search sch){
		// 데이터 총 건수 처리
		sch.setCount(dao.getCount(sch));
						
		// 화면에 한번에 보여줄 데이터 수 
		if(sch.getPageSize() == 0) { sch.setPageSize(10); }
						
		// 총 페이지 수 처리
		int pgCnt = (int)Math.ceil(sch.getCount() / (double)sch.getPageSize());
		sch.setPageCount(pgCnt == 0 ? 1 : pgCnt);
						
		// 현재 클릭한 페이지 수 설정, 초기값 1
		if(sch.getCurPage() == 0) { sch.setCurPage(1); }
						
		// next 클릭시, 전체 페이지 수를 넘지 않게 처리
		if(sch.getCurPage() > sch.getPageCount()) {
			sch.setCurPage(sch.getPageCount()); 
		}
						
		// 현재 클릭한 페이지 번호를 통해서 시작 번호와 마지막 번호를 전송처리 
		sch.setStart((sch.getCurPage() - 1) * sch.getPageSize() + 1);
		sch.setEnd(sch.getCurPage() * sch.getPageSize());
						
		// 초기 블록값 설정
		sch.setBlockSize(5);
		// block 설정
		int blocknum = (int)Math.ceil(sch.getCurPage() / (double)sch.getBlockSize());
		int endBlock = blocknum * sch.getBlockSize();
		sch.setEndBlock(endBlock > sch.getPageCount() ? sch.getPageCount() : endBlock);
		sch.setStartBlock((blocknum - 1) * sch.getBlockSize() + 1);
		
		return dao.tlist(sch);
	}
	
	public ArrayList<Project> getProject() {
		return dao.getProject();
	}
	
	public ArrayList<Task> ptlist(){
		return dao.ptlist();
	}
	
	@Value("${upload}")
	private String upload;
	@Value("${tmpupload}")
	private String tmpupload;
	
	public void insertTask(Task insert) {
		System.out.println("경로 1: " + upload);
		System.out.println("경로 2: " + tmpupload);
		
		// String task_file_name = upload(insert);
		System.out.println("데이터 처리 1");
		
		System.out.println(insert.getName());
		System.out.println(insert.getTask_name());
		System.out.println(insert.getPro_title());
		System.out.println(insert.getPro_state());
		System.out.println(insert.getPro_statenum());
		System.out.println(insert.getSort());
		System.out.println(insert.getDifficulty());
		System.out.println(insert.getTask_sdate());
		System.out.println(insert.getDeadline());
		System.out.println(insert.getTask_content());
		System.out.println(insert.getReport());
		
		dao.insertTask(insert);
		
		/*
		 * System.out.println(task_file_name + ": " + insert.getTask_name());
		 * 
		 * if(task_file_name != null && !task_file_name.equals("")) { dao.fileUpload(new
		 * Task_File(task_file_name, insert.getTask_name()));
		 * System.out.println("데이터 처리 2"); }
		 */

	}
	
	public void updateTask(Task upt) {
		String task_file_name = upload(upt);
		
		// 수정에서 파일을 업로드한 데이터가 있을 때,
		if(task_file_name != null && !task_file_name.equals("")) {
			// DB에서 파일 정보 추가/수정
			Task_File ta = new Task_File();
			ta.setTask_file_co(upt.getTask_co());
			ta.setTask_file_name(task_file_name);
			ta.setTask_file_content(upt.getTask_name());
			
			dao.updateFile(ta);
		}
		
		dao.updateTask(upt);
	}
	
	public Task getTask (String task_co) {
		Task t = dao.getTask(task_co);
		t.setTask_file_name("");
		if(dao.getFile(task_co) != null) {
			t.setTask_file_name(dao.getFile(task_co).getTask_file_name());
		}
		
		return t;
	}
	
	public ArrayList<Member> getMember() {
		return dao.getMember();
	}

	// 파일 업로드 부분 기능 메서드로 공통으로 선언
	private String upload(Task t) {
		// 파일 이름 가져오기
		MultipartFile report = t.getReport();
		String task_file_name = report.getOriginalFilename();
				
		// File 객체 생성하여 처리하기
		File tmpFile = new File(tmpupload + task_file_name);
		File file = new File(upload + task_file_name);
				
		// 요청 객체로 실제 파일 객체 변환하기
			try {
				if(task_file_name != null && !task_file_name.equals("")) {
					report.transferTo(tmpFile);
					// 임시 위치에서 웹서버에 지정 폴더 복사하기
					Files.copy(tmpFile.toPath(), file.toPath(), 
							StandardCopyOption.REPLACE_EXISTING);
					System.out.println("파일 업로드 성공");
				}
						
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
						
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("파일 업로드 시 에러 발생");
						
			}
					
			return task_file_name;
	}
	
}
