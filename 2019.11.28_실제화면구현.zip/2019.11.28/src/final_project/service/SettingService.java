package final_project.service;
//final_project.service.SettingService

import java.util.ArrayList;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import final_project.dao.SettingDao;
import final_project.vo.Member;
import final_project.vo.Search;

@Service
public class SettingService {
	@Autowired
	private SettingDao dao;
	
	public ArrayList<Member> elist(Search sch){
		
		// PM 데이터 총건수 처리
		sch.setCount(dao.getCount(sch));
		
		//화면에 한번에 보여줄 데이터 수
		if(sch.getPageSize() == 0) { sch.setPageSize(5); }
		
		//총 페이지 수 처리
		int pagCnt = (int)Math.ceil(sch.getCount() / (double)sch.getPageSize());
		sch.setPageCount(pagCnt == 0 ? 1 : pagCnt);
		
		//현재 클릭한 페이지 수 설정, 초기값 1
		if(sch.getCurPage() == 0) { sch.setCurPage(1); }
		
		// next 클릭시, 전체 페이지 수를 넘지않게 처리
		if(sch.getCurPage() > sch.getPageCount()) {
			sch.setCurPage(sch.getPageCount());
		}
		
		System.out.println("현재 클릭한 page 번호: " + sch.getCurPage());
		
		//현재 클릭한 페이지 번호를 통해서 시작번호와 마지막번호를 전송처리
		sch.setStart((sch.getCurPage() - 1) * sch.getPageSize() + 1);
		sch.setEnd(sch.getCurPage() * sch.getPageSize());
		
		System.out.println("시작번호: " + sch.getStart());
		System.out.println("마지막번호: " + sch.getEnd());
		
		//초기 블록값설정
		sch.setBlockSize(5);
		
		//block 설정
		int blocknum = (int)Math.ceil(sch.getCurPage() / (double)sch.getBlockSize());
		int endBlock = blocknum * sch.getBlockSize();
		sch.setEndBlock(endBlock > sch.getPageCount() ? sch.getPageCount() : endBlock);
		sch.setStartBlock((blocknum - 1) * sch.getBlockSize() + 1 );
		
		return dao.elist(sch);
	}
	
	public ArrayList<Member> clist(Search csch){
		// 담당자 데이터 총건수 처리
		csch.setCount(dao.getCount1(csch));
		
		//화면에 한번에 보여줄 데이터 수
		if(csch.getPageSize() == 0) { csch.setPageSize(10); }
		
		//총 페이지 수 처리
		int pageCnt = (int)Math.ceil(csch.getCount() / (double)csch.getPageSize());
		csch.setPageCount(pageCnt == 0 ? 1 : pageCnt);
		
		//현재 클릭한 페이지 수 설정, 초기값 1
		if(csch.getCurPage() == 0) { csch.setCurPage(1); }
		
		// next 클릭시, 전체 페이지 수를 넘지않게 처리
		if(csch.getCurPage() > csch.getPageCount()) {
			csch.setCurPage(csch.getPageCount());
		}
		
		System.out.println("현재 클릭한 page 번호: " + csch.getCurPage());
		
		//현재 클릭한 페이지 번호를 통해서 시작번호와 마지막번호를 전송처리
		csch.setStart((csch.getCurPage() - 1) * csch.getPageSize() + 1);
		csch.setEnd(csch.getCurPage() * csch.getPageSize());
		
		System.out.println("시작번호: " + csch.getStart());
		System.out.println("마지막번호: " + csch.getEnd());
		
		//초기 블록값설정
		csch.setBlockSize(5);
		
		//block 설정
		int blocknum = (int)Math.ceil(csch.getCurPage() / (double)csch.getBlockSize());
		int endBlock = blocknum * csch.getBlockSize();
		csch.setEndBlock(endBlock > csch.getPageCount() ? csch.getPageCount() : endBlock);
		csch.setStartBlock((blocknum - 1) * csch.getBlockSize() + 1 );
		
		return dao.clist(csch);
	}
	
	public void insertMember(Member insert) {		
		
		dao.insertMember(insert);		
	}
	
	public void insert1Member(Member insert) {
		dao.insertMember1(insert);	
	}
	
	/*public Member getMember(String id);*/
	public Member getMember(String id) {		
		return dao.getMember(id);	
	}	
	
	@Value("${upload}")
	private String upload;
	@Value("${tmpupload}")
	private String tmpupload;
	
	/*public void updateMember(Member upt);*/
	public void updateMember(Member upt) {
		dao.updateMember(upt);
	}
	
	/*public void delMember(String id);*/
	public void delMember(String id) {
		dao.delMember(id);
	}
	
	/*public void adMember(Member ad); */
	public void adMember(Member ad) {
		dao.adMember(ad);
	}
	
	/*public void pmMember(Member pm); */
	public void pmMember(Member pm) {
		dao.pmMember(pm);
	}
	
	// mail
	// 1. container에 있는 mail 호출.
	@Autowired
	private JavaMailSender mailSender;
	
	//2.메일 전송처리
	public boolean sendMail(Member email) {	
		boolean isSuccess=true;
		// 1) 전송할 내용을 처리하는 MimeMessage객체 생성.
		MimeMessage msg = mailSender.createMimeMessage();
		
		try {
			// 2) 발신자 지정
			msg.setFrom(new InternetAddress(email.getSender()));
			// 3) 수신자 지정.
			msg.setRecipient(RecipientType.TO, new InternetAddress(email.getId()));
			// 4) 제목 지정.
			msg.setSubject("PMS에 가입하신것을 환영합니다.");
			// 5) 내용 지정.			
			msg.setText("아이디와 비밀번호를 알려드립니다." +
						"\n 아이디:" + email.getId() + 
						"\n 비밀번호:" + email.getPass() + 
						"\n http://192.168.0.40:7080/a03_team/pms.do?method=loginForm" + 
						"\n PMS 사이트에 들어오셔서 아이디와 비밀번호로 로그인하면 할 수 있습니다.");					
			// 6) 발송 처리..
			mailSender.send(msg);
			
			// 발송 정상 여부 설정 
			isSuccess =true;
			// 7) 예외처리..			
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("예외:"+e.getMessage());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("예외:"+e.getMessage());
		} catch(Exception e) {
			System.out.println("예외:"+e.getMessage());
		}
		
		return isSuccess;
	}
	
	//public ArrayList<Member> elist(Search psch);
	/*public ArrayList<Member> pmname(Search pmname);	
	public ArrayList<Member> pmname(Search pmname){		
		// PM 데이터 총건수 처리
		pmname.setCount(dao.getCount(pmname));
		
		//화면에 한번에 보여줄 데이터 수
		if(pmname.getPageSize() == 0) { pmname.setPageSize(5); }
		
		//총 페이지 수 처리
		int pagCnt = (int)Math.ceil(pmname.getCount() / (double)pmname.getPageSize());
		pmname.setPageCount(pagCnt == 0 ? 1 : pagCnt);
		
		//현재 클릭한 페이지 수 설정, 초기값 1
		if(pmname.getCurPage() == 0) { pmname.setCurPage(1); }
		
		// next 클릭시, 전체 페이지 수를 넘지않게 처리
		if(pmname.getCurPage() > pmname.getPageCount()) {
			pmname.setCurPage(pmname.getPageCount());
		}
		
		System.out.println("현재 클릭한 pmname page 번호: " + pmname.getCurPage());
		
		//현재 클릭한 페이지 번호를 통해서 시작번호와 마지막번호를 전송처리
		pmname.setStart((pmname.getCurPage() - 1) * pmname.getPageSize() + 1);
		pmname.setEnd(pmname.getCurPage() * pmname.getPageSize());
		
		System.out.println("pmname 시작번호: " + pmname.getStart());
		System.out.println("pmname 마지막번호: " + pmname.getEnd());
		
		//초기 블록값설정
		pmname.setBlockSize(5);
		
		//block 설정
		int blocknum = (int)Math.ceil(pmname.getCurPage() / (double)pmname.getBlockSize());
		int endBlock = blocknum * pmname.getBlockSize();
		pmname.setEndBlock(endBlock > pmname.getPageCount() ? pmname.getPageCount() : endBlock);
		pmname.setStartBlock((blocknum - 1) * pmname.getBlockSize() + 1 );
		
		//return dao.pmname(pmname);
	}
	*/
	
	
	
	/* public void pmad(Member pmad);
	public void pmad(Member pmad) {
		dao.pmad(pmad);
	}
	 */
	/*public void meid(Member meid);
	public void meid(Member meid) {
		dao.meid(meid);
	}
	*/
	/*public void mename(Member mename);
	public void mename(Member mename) {
		dao.mename(mename);
	}
	*/
}