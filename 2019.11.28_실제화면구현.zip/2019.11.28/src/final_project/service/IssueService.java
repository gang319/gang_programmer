package final_project.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import final_project.dao.IssueDao;
import final_project.vo.Att_File;
import final_project.vo.Issue;
import final_project.vo.Member;
import final_project.vo.Search;

@Service
public class IssueService {
	@Autowired
	private IssueDao dao;
	
	public ArrayList<Issue> issueList(Search sch) { 
		// 데이터 총 건수 처리
		sch.setCount(dao.getCount(sch));
		
		// 화면에 한번에 보여줄 데이터 수 
		if(sch.getPageSize() == 0) { sch.setPageSize(5); }
		
		// 총 페이지 수 처리
		int pgCnt = (int)Math.ceil(sch.getCount() / (double)sch.getPageSize());
		sch.setPageCount(pgCnt == 0 ? 1 : pgCnt);
		
		// 현재 클릭한 페이지 수 설정, 초기값 1
		if(sch.getCurPage() == 0) { sch.setCurPage(1); }
		
		// next 클릭시, 전체 페이지 수를 넘지 않게 처리
		if(sch.getCurPage() > sch.getPageCount()) {
			sch.setCurPage(sch.getPageCount()); 
		}
		
		System.out.println("현재 클릭한 page 번호: " + sch.getCurPage());
		
		// 현재 클릭한 페이지 번호를 통해서 시작 번호와 마지막 번호를 전송처리 
		sch.setStart((sch.getCurPage() - 1) * sch.getPageSize() + 1);
		sch.setEnd(sch.getCurPage() * sch.getPageSize());
		
		System.out.println("시작번호: " + sch.getStart());
		System.out.println("마지막번호: " + sch.getEnd());
		
		// 초기 블록값 설정
		sch.setBlockSize(5);
		// block 설정
		int blocknum = (int)Math.ceil(sch.getCurPage() / (double)sch.getBlockSize());
		int endBlock = blocknum * sch.getBlockSize();
		sch.setEndBlock(endBlock > sch.getPageCount() ? sch.getPageCount() : endBlock);
		sch.setStartBlock((blocknum - 1) * sch.getBlockSize() + 1);
		
		return dao.issueList(sch);
	}
	 
	/*
	 * public ArrayList<Issue> issueList(Issue sch) { return dao.issueList(sch); }
	 */
	
	public Issue getIssue(String issue_co) {
		Issue is = dao.getIssue(issue_co);
		is.setFile_name("");
		if(dao.getFile(issue_co) != null) {
			is.setFile_name(dao.getFile(issue_co).getFile_name());
		}
		
		return is;
		
		// return dao.getIssue(issue_co);
		
	}
	
	public ArrayList<Member> getManager() {
		return dao.getManager();
	}
	
	@Value("${upload}")
	private String upload;
	@Value("${tmpupload}")
	private String tmpupload;
	
	public void insertIssue(Issue ins) {
		System.out.println("경로 1: " + upload);
		System.out.println("경로 2: " + tmpupload);
		
		System.out.println("데이터 처리 1");
		dao.insertIssue(ins);
		
		String file_name = upload(ins);
		
		if(file_name != null && !file_name.equals("")) {
			dao.fileUpload(new Att_File(ins.getIssue_co(), file_name, ins.getTitle()));
			System.out.println("데이터 처리 2");
		}else {
			
		}
		
		System.out.println(file_name + ": " + ins.getTitle());
/*
		INSERT INTO att_file
		VALUES('A-'||file_seq.nextval, (SELECT issue_co FROM issue WHERE issue_co = #{ issue_co }), 
		#{ file_name }, #{ org_name })
 * */		
		
		
		
	}
	
	public void insertRef(Issue ins) {
		System.out.println("경로 1: " + upload);
		System.out.println("경로 2: " + tmpupload);
		
		String file_name = upload(ins);
		
		if(file_name != null && !file_name.equals("")) {
			dao.fileUpload(new Att_File(file_name, ins.getTitle()));
			System.out.println("데이터 처리 2");
		}
		
		System.out.println("데이터 처리 1");
		dao.insertRef(ins);
		
		System.out.println(file_name + ": " + ins.getTitle());
		
		
		
	}
	
	public void updateIssue(Issue upt) {
		String file_name = upload(upt);
		
		// 수정에서 파일을 업로드한 데이터가 있을 때,
		if(file_name != null && !file_name.equals("")) {
			// DB에서 파일 정보 추가/수정
			Att_File at = new Att_File();
			at.setIssue_co(upt.getIssue_co());
			at.setFile_name(file_name);
			at.setOrg_name(upt.getTitle());
			
			dao.updateFile(at);
		}
		
		dao.updateIssue(upt);
	}
	
	public void updateRef(Issue upt) {
		String file_name = upload(upt);
		
		// 수정에서 파일을 업로드한 데이터가 있을 때,
		if(file_name != null && !file_name.equals("")) {
			// DB에서 파일 정보 추가/수정
			Att_File at = new Att_File();
			at.setIssue_co(upt.getIssue_co());
			at.setFile_name(file_name);
			at.setOrg_name(upt.getTitle());
			
			dao.updateFile(at);
		}
		
		dao.updateRef(upt);
	}
	
	public void success(String issue_co) {
		dao.success(issue_co);
	}
	
	public void deleteIssue(String issue_co) {
		dao.deleteIssue(issue_co);
	}
	
	// 파일 업로드 부분 기능 메서드로 공통으로 선언
		private String upload(Issue i) {
			// 파일 이름 가져오기
			MultipartFile report = i.getReport();
			String file_name = report.getOriginalFilename();
			
			// File 객체 생성하여 처리하기
			File tmpFile = new File(tmpupload + file_name);
			File file = new File(upload + file_name);
			
			// 요청 객체로 실제 파일 객체 변환하기
				try {
					if(file_name != null && !file_name.equals("")) {
						report.transferTo(tmpFile);
						// 임시 위치에서 웹서버에 지정 폴더 복사하기
						Files.copy(tmpFile.toPath(), file.toPath(), 
								StandardCopyOption.REPLACE_EXISTING);
						System.out.println("파일 업로드 성공");
					}
					
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("파일 업로드 시 에러 발생");
					
				}
				
				return file_name;
		}

}
