package final_project.vo;

import java.util.Date;

public class Message {
	private String msg_code;
	private String msg_sender;
	private String msg_receiver;
	private String msg_content;
	private Date msg_sendTime;
	private Date msg_readTime;
	private String chat_code;
	private String name;
	private String receiver_name;
	
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getMsg_code() {
		return msg_code;
	}

	public void setMsg_code(String msg_code) {
		this.msg_code = msg_code;
	}

	public String getMsg_sender() {
		return msg_sender;
	}

	public void setMsg_sender(String msg_sender) {
		this.msg_sender = msg_sender;
	}

	public String getMsg_receiver() {
		return msg_receiver;
	}

	public void setMsg_receiver(String msg_receiver) {
		this.msg_receiver = msg_receiver;
	}

	public String getMsg_content() {
		return msg_content;
	}

	public void setMsg_content(String msg_content) {
		this.msg_content = msg_content;
	}

	public Date getMsg_sendTime() {
		return msg_sendTime;
	}

	public void setMsg_sendTime(Date msg_sendTime) {
		this.msg_sendTime = msg_sendTime;
	}

	public Date getMsg_readTime() {
		return msg_readTime;
	}

	public void setMsg_readTime(Date msg_readTime) {
		this.msg_readTime = msg_readTime;
	}

	public String getChat_code() {
		return chat_code;
	}

	public void setChat_code(String chat_code) {
		this.chat_code = chat_code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReceiver_name() {
		return receiver_name;
	}

	public void setReceiver_name(String receiver_name) {
		this.receiver_name = receiver_name;
	}

}
