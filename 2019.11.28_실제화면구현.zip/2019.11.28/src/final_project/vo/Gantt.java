package final_project.vo;

import java.util.ArrayList;

public class Gantt {
	private String pname;
	private long pro_co;
	private ArrayList<Tasks> tasks;
	private ArrayList<Resources> resources;
	private ArrayList<Roles> roles;
	private ArrayList<DeletedTaskIds> deletedTaskIds;
	private long selectedRow;
	private long canWrite;
	private long canWriteOnParent;
	private long canDelete;
	private long canAdd;
	

	public Gantt() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Gantt(long pro_co, ArrayList<Tasks> tasks, ArrayList<Resources> resources, ArrayList<Roles> roles,
			ArrayList<DeletedTaskIds> deletedTaskIds, long selectedRow, long canWrite, long canWriteOnParent,
			long canDelete, long canAdd) {
		super();
		this.pro_co = pro_co;
		this.tasks = tasks;
		this.resources = resources;
		this.roles = roles;
		this.deletedTaskIds = deletedTaskIds;
		this.selectedRow = selectedRow;
		this.canWrite = canWrite;
		this.canWriteOnParent = canWriteOnParent;
		this.canDelete = canDelete;
		this.canAdd = canAdd;
	}
	
	

	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public long getPro_co() {
		return pro_co;
	}


	public void setPro_co(long pro_co) {
		this.pro_co = pro_co;
	}


	public ArrayList<Tasks> getTasks() {
		return tasks;
	}


	public void setTasks(ArrayList<Tasks> tasks) {
		this.tasks = tasks;
	}


	public ArrayList<Resources> getResources() {
		return resources;
	}


	public void setResources(ArrayList<Resources> resources) {
		this.resources = resources;
	}


	public ArrayList<Roles> getRoles() {
		return roles;
	}


	public void setRoles(ArrayList<Roles> roles) {
		this.roles = roles;
	}


	public ArrayList<DeletedTaskIds> getDeletedTaskIds() {
		return deletedTaskIds;
	}


	public void setDeletedTaskIds(ArrayList<DeletedTaskIds> deletedTaskIds) {
		this.deletedTaskIds = deletedTaskIds;
	}


	public long getSelectedRow() {
		return selectedRow;
	}


	public void setSelectedRow(long selectedRow) {
		this.selectedRow = selectedRow;
	}


	public long getCanWrite() {
		return canWrite;
	}


	public void setCanWrite(long canWrite) {
		this.canWrite = canWrite;
	}


	public long getCanWriteOnParent() {
		return canWriteOnParent;
	}


	public void setCanWriteOnParent(long canWriteOnParent) {
		this.canWriteOnParent = canWriteOnParent;
	}


	public long getCanDelete() {
		return canDelete;
	}


	public void setCanDelete(long canDelete) {
		this.canDelete = canDelete;
	}


	public long getCanAdd() {
		return canAdd;
	}


	public void setCanAdd(long canAdd) {
		this.canAdd = canAdd;
	}


	
	
	
	
	


}
