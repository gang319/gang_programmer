package final_project.vo;

public class Scheduler {
	private int id;
	private String title;
	private String name;
	private String content;
	private String pro_state;
	private String start;
	private String end;
	private String color;
	private String textColor;
	private boolean allDay;
	public Scheduler() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Scheduler(int id, String title, String name, String content, String pro_state, String start, String end,
			String color, String textColor, boolean allDay) {
		super();
		this.id = id;
		this.title = title;
		this.name = name;
		this.content = content;
		this.pro_state = pro_state;
		this.start = start;
		this.end = end;
		this.color = color;
		this.textColor = textColor;
		this.allDay = allDay;
	}
	public Scheduler(String title, String name, String pro_state, String start, String end, boolean allDay) {
		super();
		this.title = title;
		this.name = name;
		this.pro_state = pro_state;
		this.start = start;
		this.end = end;
		this.allDay = allDay;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPro_state() {
		return pro_state;
	}
	public void setPro_state(String pro_state) {
		this.pro_state = pro_state;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTextColor() {
		return textColor;
	}
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	public boolean getAllDay() {
		return allDay;
	}
	public void setAllDay(boolean allDay) {
		this.allDay = allDay;
	}
}
