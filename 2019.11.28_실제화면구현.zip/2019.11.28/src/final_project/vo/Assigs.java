package final_project.vo;

public class Assigs {
	private long pro_co;
	private long tid;
	private String resourceId;
	private String id;
	private String roleId;
	private long effort;
	public long getTid() {
		return tid;
	}
	public void setTid(long tid) {
		this.tid = tid;
	}
	public String getResourceId() {
		return resourceId;
	}
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public long getEffort() {
		return effort;
	}
	public void setEffort(long effort) {
		this.effort = effort;
	}
	public long getPro_co() {
		return pro_co;
	}
	public void setPro_co(long pro_co) {
		this.pro_co = pro_co;
	}
	

	
	
	


}
