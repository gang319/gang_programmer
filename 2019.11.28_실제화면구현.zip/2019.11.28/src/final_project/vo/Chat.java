package final_project.vo;

public class Chat {
	private String chat_code;
	private String name;
	
	public Chat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getChat_code() {
		return chat_code;
	}

	public void setChat_code(String chat_code) {
		this.chat_code = chat_code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
