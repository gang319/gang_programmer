package final_project.vo;

public class Ph_file {
	private String ph_co;
	private String mem_co;
	private String ph_name;
	private String ph_org_name;
	
	public Ph_file() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ph_file(String ph_co, String mem_co, String ph_name, String ph_org_name) {
		super();
		this.ph_co = ph_co;
		this.mem_co = mem_co;
		this.ph_name = ph_name;
		this.ph_org_name = ph_org_name;
	}

	public Ph_file(String ph_co, String mem_co, String ph_name) {
		super();
		this.ph_co = ph_co;
		this.mem_co = mem_co;
		this.ph_name = ph_name;
	}

	public Ph_file(String ph_name, String ph_org_name) {
		super();
		this.ph_name = ph_name;
		this.ph_org_name = ph_org_name;
	}

	public String getPh_co() {
		return ph_co;
	}

	public void setPh_co(String ph_co) {
		this.ph_co = ph_co;
	}

	public String getMem_co() {
		return mem_co;
	}

	public void setMem_co(String mem_co) {
		this.mem_co = mem_co;
	}

	public String getPh_name() {
		return ph_name;
	}

	public void setPh_name(String ph_name) {
		this.ph_name = ph_name;
	}

	public String getPh_org_name() {
		return ph_org_name;
	}

	public void setPh_org_name(String ph_org_name) {
		this.ph_org_name = ph_org_name;
	}
}
