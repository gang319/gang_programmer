package final_project.vo;

import java.util.ArrayList;

public class Tasks {
	private long pro_co;
	private long id;
	private String name;
	private String code;
	private long level;
	private String status;
	private long start;
	private long duration;
	private long end;
	private boolean startIsMilestone;
	private boolean endIsMilestone;
	private ArrayList<Assigs> assigs;
	private String depends;
	private String description;
	private long progress;
	public long getPro_co() {
		return pro_co;
	}
	public void setPro_co(long pro_co) {
		this.pro_co = pro_co;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public long getLevel() {
		return level;
	}
	public void setLevel(long level) {
		this.level = level;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getStart() {
		return start;
	}
	public void setStart(long start) {
		this.start = start;
	}
	public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	public long getEnd() {
		return end;
	}
	public void setEnd(long end) {
		this.end = end;
	}
	public boolean isStartIsMilestone() {
		return startIsMilestone;
	}
	public void setStartIsMilestone(boolean startIsMilestone) {
		this.startIsMilestone = startIsMilestone;
	}
	public boolean isEndIsMilestone() {
		return endIsMilestone;
	}
	public void setEndIsMilestone(boolean endIsMilestone) {
		this.endIsMilestone = endIsMilestone;
	}
	public ArrayList<Assigs> getAssigs() {
		return assigs;
	}
	public void setAssigs(ArrayList<Assigs> assigs) {
		this.assigs = assigs;
	}
	public String getDepends() {
		return depends;
	}
	public void setDepends(String depends) {
		this.depends = depends;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getProgress() {
		return progress;
	}
	public void setProgress(long progress) {
		this.progress = progress;
	}
}
