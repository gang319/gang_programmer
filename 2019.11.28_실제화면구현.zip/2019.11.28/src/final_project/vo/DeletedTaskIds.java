package final_project.vo;

public class DeletedTaskIds {
	private long pro_co;
	private String id;
	
	public long getPro_co() {
		return pro_co;
	}
	public void setPro_co(long pro_co) {
		this.pro_co = pro_co;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	
	
}
