package final_project.vo;

public class Task_File {
	private String task_file_co;
	private String task_co;
	private String task_file_name;
	private String task_file_content;
	
	public Task_File() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Task_File(String task_file_co, String task_file_name, String task_file_content) {
		super();
		this.task_file_co = task_file_co;
		this.task_file_name = task_file_name;
		this.task_file_content = task_file_content;
	}

	public Task_File(String task_file_name, String task_file_content) {
		super();
		this.task_file_name = task_file_name;
		this.task_file_content = task_file_content;
	}

	public String getTask_file_co() {
		return task_file_co;
	}

	public void setTask_file_co(String task_file_co) {
		this.task_file_co = task_file_co;
	}

	public String getTask_co() {
		return task_co;
	}

	public void setTask_co(String task_co) {
		this.task_co = task_co;
	}

	public String getTask_file_name() {
		return task_file_name;
	}

	public void setTask_file_name(String task_file_name) {
		this.task_file_name = task_file_name;
	}

	public String getTask_file_content() {
		return task_file_content;
	}

	public void setTask_file_content(String task_file_content) {
		this.task_file_content = task_file_content;
	}

}
