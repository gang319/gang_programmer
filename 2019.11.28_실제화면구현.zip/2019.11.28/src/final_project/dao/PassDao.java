package final_project.dao;
//final_project.dao.PassDao
import org.springframework.stereotype.Repository;
import final_project.vo.Member;

@Repository
public interface PassDao {
	public Member pass(Member p);
}
