package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Issue;
import final_project.vo.Member;
import final_project.vo.Search;
import final_project.vo.Task;

@Repository
public interface MemberDao {
	public Member memlogin(Member m);
	
	public int getIsCount(Search isch);
	
	public ArrayList<Issue> issueList(Search isch);
	
	public int getTasCount(Search tsch);
	
	public ArrayList<Task> tlist(Search tsch);

}
