package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Member;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;
import final_project.vo.Task_File;

@Repository
public interface TaskDao {
	public int getCount(Search sch);
	
	public ArrayList<Task> tlist(Search sch);
	
	public ArrayList<Project> getProject();
	
	public ArrayList<Task> ptlist();
	
	public void insertTask(Task insert);
	
	public void updateTask(Task upt);
	
	public Task getTask (String task_co);
	
	public ArrayList<Member> getMember();
	
	public void fileUpload(Task_File upl);

	public Task_File getFile(String task_co);
	
	public void updateFile(Task_File upt);
}
