package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Scheduler;

@Repository
public interface schedulerDao {
	public ArrayList<Scheduler> list();
	public void insertScheduler(Scheduler ins);
	public void updateScheduler(Scheduler upt);
	public void deleteScheduler(int id);
}
