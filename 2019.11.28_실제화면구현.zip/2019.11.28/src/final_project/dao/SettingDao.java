package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Member;
import final_project.vo.Search;

@Repository
public interface SettingDao {	
	
	/*설정 담당자 조회*/
	public ArrayList<Member> elist(Search psch);
	//public ArrayList<Member> elist(Search sch);	
	
	/*PM 추가*/
	void insertMember(Member insert);
	
	/*담당자 추가*/
	void insertMember1(Member ins);
	
	/*담당자 detail*/
	public Member getMember(String id);
	
	public void updateMember(Member upt);
	
	/*담당자 수정*/
	public void uptMember(String id);
	
	/*담당자 삭제*/
	public void delMember(String id);
	
	/*설정 고객 조회*/
	public ArrayList<Member> clist(Search csch);
	
	/*ADMIN*/
	public void adMember(Member ad);
	
	/*PM*/
	public void pmMember(Member pm);
	
	/*프로젝트 이동*/
	
	
	//PM 총 데이터 건수
	public int getCount(Search sch);
	
	//담당자 총 데이터 건수
	public int getCount1(Search csch);
	
	//pm name별보기 pmname
	//public ArrayList<Member> clist(Search csch);
	//public ArrayList<Member> pmname(Search pmname);
	
	//admin권한 - pmad
	//public void pmad(Member pmad);
	
	//id별보기 - meid
	//public void meid(Member meid);
	
	//이름별보기 - mename
	//public void mename(Member mename);
	
}
