package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Chat;
import final_project.vo.Message;

@Repository
public interface ChatDao {
	public void createRoom(Chat ins);
	
	public Chat isRoom(Chat c);
	
	public void insertMsg(Message ins);
	
	public String getMember(Chat c);
	
	public String getName(String str);
	
	public ArrayList<Message> getMessageList(String str);
	
	public ArrayList<Chat> getRoomList(String str);
	
	public Message getRecentMessage(String str);

	public void updateReadTime(String name);
	

}
