package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Member;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;

@Repository
public interface ProjectDao {
	public int getCount(Search sch);
	
	public ArrayList<Project> plist(Search sch);
	
	public Project getProject(String pro_co);
	
	public double sts_num1();
	
	public double sts_num2();
	
	public double sts_num3();
	
	public double sts_num4();
	
	public double sts_num5();
	
	public double sts_num6();
	
	public double sts_num7();

	public void insertProject(Project insert);
	
	public ArrayList<Task> getProTask(String pro_co);
	
	public ArrayList<Member> getMember();
	
	public void updateProject(Project upt);
	
	public void deleteProject(Project del);
	
}


