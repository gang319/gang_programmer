package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Att_File;
import final_project.vo.Issue;
import final_project.vo.Member;
import final_project.vo.Search;

@Repository
public interface IssueDao {
	public int getCount(Search sch);
	
	// public ArrayList<Issue> issueList(Issue sch);
	
	public ArrayList<Issue> issueList(Search sch);
	
	public Issue getIssue(String issue_co);
	
	public ArrayList<Member> getManager();
	
	public void insertIssue(Issue ins);
	
	public void insertRef(Issue ins);
	
	public void updateIssue(Issue upt);
	
	public void updateRef(Issue upt);
	
	public void success(String issue_co);
	
	public void deleteIssue(String issue_co);
	
	public void fileUpload(Att_File upl);

	public Att_File getFile(String issue_co);
	
	public void updateFile(Att_File upt);
}
