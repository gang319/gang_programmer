package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Assigs;
import final_project.vo.DeletedTaskIds;
import final_project.vo.Gantt;
import final_project.vo.Resources;
import final_project.vo.Roles;
import final_project.vo.Tasks;

@Repository
public interface GanttDao {
	public ArrayList<Tasks> tlist(long proco);
	public ArrayList<Gantt> getproco();
	public long getTproco();
	public void uptpname(long Tproco);
	
	public ArrayList<Assigs> getAssigs(long tid, long pro_co);
	public ArrayList<Resources> relist();
	public ArrayList<Roles> rolist();
	public ArrayList<DeletedTaskIds> dlist(long proco);
	public Gantt glist(long proco);
	
	public void insertGantt();
	public void insertNewTasks(Tasks insert);
	public void insertNewAssigs(Assigs insert);
	public void insertNewResources(Resources insert);
	public void insertDeletedId(String insert);
	
	public void insertNormalResources(Resources insert);
	public void insertNormalTasks(Tasks insert);
	public void insertNormalAssigs(Assigs insert);
	
	public void deleteGantt(long proco);
	public void deleteTasks(long proco);
	public void deleteAssigs(long proco);
	public void deleteResources();
	public void deleteDeletedId(long proco);
}
