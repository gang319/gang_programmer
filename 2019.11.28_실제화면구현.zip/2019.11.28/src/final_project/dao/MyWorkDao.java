package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;
import final_project.vo.Task_File;

@Repository
public interface MyWorkDao {
	public ArrayList<Project> getProject(Project sch);
	
	public ArrayList<Task> getTask(Task sch);
	
	public ArrayList<Issue> getIssue(Issue sch);
	
	public Project getProjectDet(String pro_co);
	
	public Task getTaskDet(String task_co);
	
	public void updateProject(Project upt);
	
	public void updateTask(Task upt);
	
	public Task_File getFile(String task_co);
	
	public void updateFile(Task_File upt);
	
	
}
