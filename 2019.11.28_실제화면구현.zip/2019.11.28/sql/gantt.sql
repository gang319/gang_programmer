DROP TABLE assigs;
DROP TABLE deletedTaskIds;
DROP TABLE resources;
DROP TABLE roles;
DROP TABLE tasks;
DROP TABLE gantt;

DROP SEQUENCE gpro_seq;


CREATE TABLE gantt(
	pro_co NUMBER,
	pname varchar2(100),
	selectedRow NUMBER DEFAULT 0,
	canWrite NUMBER DEFAULT 1,
	canWriteOnParent NUMBER DEFAULT 1,
	canDelete NUMBER DEFAULT 1,
	canAdd NUMBER DEFAULT 1
);

CREATE SEQUENCE gpro_seq
START WITH 1
INCREMENT BY 1;

INSERT INTO gantt(pro_co) VALUES(gpro_seq.nextval);
INSERT INTO gantt(pro_co) VALUES(gpro_seq.nextval);

CREATE TABLE tasks(
	pro_co NUMBER,	-- 프로젝트 코드
	id number,	-- id
	name varchar2(100),				-- 업무명
	code varchar2(100),				-- 사용 코드 ex) APP
	lev NUMBER,					-- 들여 쓰기 레벨 기본0
	status varchar2(100),			-- 작업 상태
	star NUMBER,					-- 시작일 밀리초기준
	duration NUMBER,				-- 총작업일
	end NUMBER,						-- 종료일 밀리초
	startIsMilestone NUMBER,		-- 시작일 중요체크 (true값이 오면 시작 날짜수정 불가)
	endIsMilestone NUMBER,			-- 종료일 중요체크 (true값이 오면 종료 날짜수정 불가)
	depends varchar2(100),	 		-- 의존성 ex) 7:3,8 작업7이 완료되고 작업8이 완료된 후 3일 후에 작업이 시작됨..
	description varchar2(500),		-- 상세 설명
	progress NUMBER					-- 진행률
);

INSERT INTO tasks VALUES(
	1,
	-1,
	'125렌터카 홈페이지 구축',
	'Car prj',
	0,
	'STATUS_ACTIVE',
	1557885389440,
	0,
	1557885489440,
	0,
	0,
	'',
	'',
	0
);

INSERT INTO tasks VALUES(
	2,
	-1,
	'환상 호텔 관리 프로세스 개발',
	'Hotel',
	0,
	'STATUS_ACTIVE',
	1557885389440,
	0,
	1557885489440,
	0,
	0,
	'',
	'',
	0
);

UPDATE gantt
SET pname = (SELECT name 
			FROM tasks
			WHERE lev=0
			AND pro_co = 1)
WHERE pro_co = 1;

UPDATE gantt
SET pname = (SELECT name 
			FROM tasks
			WHERE lev=0
			AND pro_co = 2)
WHERE pro_co = 2;

CREATE TABLE resources(
	id varchar2(100),		-- 리소스 ID	(팀원 ID)
	name varchar2(100)					-- 리소스 이름	(팀원 이름)
);

INSERT INTO resources VALUES ('res1','강무열');
INSERT INTO resources VALUES ('res2','조철석');
INSERT INTO resources VALUES ('res3','김동력');
INSERT INTO resources VALUES ('res4','김하훈');
INSERT INTO resources VALUES ('res5','육동철');
INSERT INTO resources VALUES ('res6','김지혜');
INSERT INTO resources VALUES ('res7','백은영');
INSERT INTO resources VALUES ('res8','박란정');
INSERT INTO resources VALUES ('res9','박한이');
INSERT INTO resources VALUES ('res10','선동렬');
INSERT INTO resources VALUES ('res11','박철민');
INSERT INTO resources VALUES ('res12','강태우');
INSERT INTO resources VALUES ('res13','이승엽');
INSERT INTO resources VALUES ('res14','이종범');
INSERT INTO resources VALUES ('res15','양준혁');


CREATE TABLE roles(
	id varchar2(100),		-- roles ID	(직책 ID) 
	name varchar2(100)			-- roles 이름	(직책 명)
);

INSERT INTO roles VALUES ('role1','관리자');
INSERT INTO roles VALUES ('role2','팀장');
INSERT INTO roles VALUES ('role3','담당자');

CREATE TABLE assigs(
	pro_co NUMBER,
	tid number, -- 업무 고유 ID
	resourceId varchar2(100),	-- 리소스 고유 ID	(팀)
	id varchar2(100),	-- assigs의 ID
	roleId varchar2(100),		-- roles의 고유 ID
	effort NUMBER				-- 작업 예상 시간
);

CREATE TABLE deletedTaskIds(
	pro_co NUMBER,
	id varchar(100)
);

COMMIT;