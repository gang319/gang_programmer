-- 사용자 --
CREATE TABLE MEMBER (
   mem_co varchar2(20) PRIMARY KEY, -- 사용자코드
   mem_sort varchar2(20), -- 사용자분류
   id varchar2(100), -- 아이디
   pass varchar2(20), -- 비밀번호
   name varchar2(20), -- 이름
   job varchar2(30), -- 직책
   phone varchar2(50), -- 전화번호
   photo varchar2(500), -- 사진
   admin_ck varchar2(10), -- 권한부여
   sender varchar2(50) -- 보낸사람
);

CREATE SEQUENCE mem_seq
	START WITH 1
	INCREMENT BY 1;

-- 사용자 추가
INSERT INTO MEMBER
VALUES ('M-'||mem_seq.nextval,'admin','admin@gmail.com','1234','유민환','관리자','010-1234-5678',NULL,'1','');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'pm','worker@gmail.com','5678','김열일','팀장','010-2345-6789',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'pm','gam123@gmail.com','gam123','감우성','팀장','010-5125-5481',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'pm','afwenago32@naver.com','hragaeh4545','김수로','팀장','010-5487-6568',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'pm','uykyuj6768@nate.com','afragth542','노민환','팀장','010-5485-7811',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'pm','gsathj65656@nate.com','agr4t34334','서상수','팀장','010-1245-7845',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','hsgrg3443@gmail.com','shdsh5454','최태웅','담당자','010-7845-8954',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','agrwhgr322@nate.com','hssrgg34t53','이충헌','담당자','010-5412-5623',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','sunsun1234@gmail.com','sun123qwe','김길동','담당자','02-999-8888',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER 
VALUES('M-'||mem_seq.nextval,'member','tayotayo@gmail.com','tayo1234','이길동','담당자','02-988-7777', NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','loooopy@naver.com','lplp12','마길동','담당자','010-5555-8888',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','crooong@nate.com','lslghel23','박길동','담당자','02-554-8569',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','eeedy99@gmail.com','12dheo23','최길동','담당자','02-554-8457',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','bananacha@gmail.com','chacha124','장길동','담당자','02-779-5587',NULL,'0','admin@gmail.com');

INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','customer1@naver.com','cus123','김철수','담당자','032-345-2234',NULL,'0','admin@gmail.com');

-- 사용자 추가
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','aafwg@naver.com','cus123','강무열','담당자','032-345-2574',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','wagrag@naver.com','agaw','조철석','담당자','032-345-6637',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','htaht@naver.com','agreegw','김동력','담당자','032-345-6439',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','awewagre@naver.com','hteyrht','김하훈','담당자','032-345-1136',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','agreagbr@naver.com','32ra3r','육동철','담당자','032-345-9787',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','ahreagre@naver.com','dgdafsrg','김지혜','담당자','032-345-8345',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','sdcfdaer@naver.com','wawerrgfa','백은영','담당자','032-345-2152',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','ahrea@naver.com','43wagta','박란정','담당자','032-345-8345',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','eahteaer@naver.com','afaagwfaw','박한이','담당자','032-345-1837',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','wgrarrar@naver.com','cusgaga123','선동렬','담당자','032-345-3453',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','afaegw@naver.com','radsfgar','채태인','담당자','032-345-2434',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','gaggrarr@naver.com','b54wsag','강태우','담당자','032-345-3435',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','aewafrag@naver.com','vu65bew56','이승엽','담당자','032-7345-3754',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','awhgtaht@naver.com','nj76e6','이종범','담당자','032-345-2234',NULL,'0','admin@gmail.com');
INSERT INTO MEMBER
VALUES('M-'||mem_seq.nextval,'member','wgrarrar@naver.com','cusgaga123','양준혁','담당자','032-345-2234',NULL,'0','admin@gmail.com');

SELECT * FROM MEMBER;

-- 프로젝트 --

CREATE TABLE project(
	pro_co varchar2(20) PRIMARY KEY, -- 프로젝트 코드
	mem_co varchar2(20) REFERENCES member(mem_co), -- PM 멤버코드
	pro_title varchar2(200), -- 프로젝트 명
	name varchar2(20), -- PM 이름
	pro_date DATE, -- 프로젝트 시작일
	last_date DATE, -- 프로젝트 마감일
	pro_gress NUMBER -- 진행률
);

CREATE SEQUENCE pro_seq
	START WITH 1
	INCREMENT BY 1;

INSERT INTO PROJECT
VALUES('P-'||pro_seq.nextval,'M-2','125렌터카 홈페이지 구축','김열일','2019-10-01','2019-11-25',75);

INSERT INTO PROJECT
VALUES('P-'||pro_seq.nextval,'M-3','환상 호텔 관리 프로세스 개발','감우성','2019-10-15','2019-12-09',60);

INSERT INTO PROJECT
VALUES('P-'||pro_seq.nextval,'M-4','ANNAWA 데이터베이스 정규화','김수로','2019-11-01','2019-11-30',70);

INSERT INTO PROJECT
VALUES('P-'||pro_seq.nextval,'M-5','SPOMENTOR 프로그램 개발','노민환','2019-11-12','2019-12-27',55);

INSERT INTO PROJECT
VALUES('P-'||pro_seq.nextval,'M-6','PMS 프로그램 개발','서상수','2019-11-13','2019-11-28',20);

SELECT * FROM PROJECT;

-- 프로젝트 별 상태 퍼센트 구하기
SELECT t.pro_state, COUNT(*) AS total, ROUND( (COUNT(*) / (SELECT COUNT(*) FROM TASK WHERE pro_co = 'P-1')) * 100, 2 ) AS Percentage
FROM PROJECT p, TASK t
WHERE t.pro_co = 'P-1'
AND p.PRO_CO = t.PRO_CO
AND t.PRO_STATE = '종료'
GROUP BY PRO_STATE;

-- 업무 --

CREATE TABLE task(
   task_co varchar2(20) PRIMARY KEY, -- 업무코드
   mem_co varchar2(20) REFERENCES member(mem_co), -- 사용자코드
   pro_co varchar2(20) REFERENCES project(pro_co), -- 프로젝트코드
   task_name varchar2(200), -- 업무명
   pro_state varchar2(20), -- 프로세스
   pro_statenum number, -- 프로세스순서
   sort varchar2(30), -- 분류
   task_rank number, -- 우선순위
   difficulty varchar2(10), -- 난이도
   task_sdate DATE, -- 업무시작일
   deadline DATE, -- 업무마감일
   pro_title varchar2(200), -- 프로젝트 명
   name varchar2(20), -- 담당자 이름
   task_content varchar2(1000)
);

CREATE SEQUENCE task_seq
	START WITH 1
	INCREMENT BY 1;

/*task 업무 테이블 데이터 생성*/
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-7','P-1','사용자 컨트롤러 구축','종료',7,'기능추가',3,'중','2019-10-05','2019-10-12','125렌터카 홈페이지 구축', '최태웅','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-8','P-1','결제 서비스 연동','착수',1,'신규',1,'상','2019-11-11','2019-11-18','125렌터카 홈페이지 구축','이길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-9','P-1','홈페이지 디자인 수정','실행통제',5,'디자인요청',1,'상','2019-11-11','2019-11-20','125렌터카 홈페이지 구축','이충헌','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-10','P-2','로그인 기능 추가','종료',7,'기능추가',1,'중','2019-10-17','2019-10-20','환상 호텔 관리 프로세스 개발','마길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-11','P-2','청구서 기능','기획',2,'기능추가',4,'상','2019-11-07','2019-11-15','환상 호텔 관리 프로세스 개발','김길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-12','P-3','메인화면 목록 수정','기획',2,'기능추가',2,'하','2019-11-07','2019-11-18','ANNAWA 데이터베이스 정규화','박길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-13','P-5','관리자 대시보드 작업 완료율','통제',6,'개발수정',1,'상','2019-11-14','2019-11-21','PMS 프로그램 개발','최길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-14','P-5','관리자 대시보드 업무확인','기획',2,'버그수정',2,'상','2019-11-12','2019-11-17','PMS 프로그램 개발','장길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-15','P-5','청구서 발송 에러 수정','기획통제',3,'버그수정',5,'중','2019-11-07','2019-11-27','PMS 프로그램 개발','김철수','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-7','P-3','평균 연령 기능 추가','실행통제',5,'기능추가',1,'중','2019-11-07','2019-11-21','ANNAWA 데이터베이스 정규화','최태웅','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-8','P-4','각 기능별 정렬 기능','기획통제',3,'기능추가',5,'상','2019-11-13','2019-11-30','SPOMENTOR 프로그램 개발','이길동','');

INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-9','P-4','동호회 컨트롤러 버그 수정','통제',6,'개발수정',3,'중','2019-11-13','2019-11-16','SPOMENTOR 프로그램 개발','이충헌','');


-- 업무 추가
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-21','P-5','회원 관리','종료',7,'기능추가',1,'상','2019-11-13','2019-11-15','PMS 프로그램 개발','강무열','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-22','P-5','공지 게시판','종료',7,'개발수정',2,'중','2019-11-22','2019-11-24','PMS 프로그램 개발','조철석','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-23','P-5','진행률 대쉬보트를 통한 확인','종료',7,'기능추가',3,'중','2019-11-20','2019-11-25','PMS 프로그램 개발','김동력','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-24','P-4','진척도 확인','종료',7,'개발수정',4,'하','2019-11-16','2019-11-21','PMS 프로그램 개발','김하훈','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-25','P-4','위험 관리','종료',7,'버그수정',5,'하','2019-11-17','2019-11-23','PMS 프로그램 개발','육동철','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-26','P-4','이슈 확인 관리','종료',7,'버그수정',1,'상','2019-11-21','2019-11-16','PMS 프로그램 개발','김지혜','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-27','P-3','형상 확인 관리','종료',7,'디자인요청',5,'하','2019-11-15','2019-11-19','PMS 프로그램 개발','백은영','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-28','P-3','문의사항 작성 관리','종료',7,'신규',2,'상','2019-11-13','2019-11-21','PMS 프로그램 개발','박란정','');
INSERT INTO TASK
VALUES('T-'||task_seq.nextval,'M-29','P-3','세부 분야 구분 및 진행률','종료',7,'신규',3,'중','2019-11-13','2019-11-23','PMS 프로그램 개발','박한이','');


SELECT * FROM task;

-- 업무 첨부 파일 --
	
CREATE TABLE task_file (
	task_file_co varchar2(20)   PRIMARY KEY, -- 업무첨부코드
	task_file_name varchar2(50), -- 파일명
	task_file_content varchar2(1000) -- 내용
);

CREATE SEQUENCE tsk_file_seq
	START WITH 1
	INCREMENT BY 1;

-- 이슈 --

CREATE TABLE issue(
   issue_co VARCHAR2(20) PRIMARY KEY, -- 이슈 코드
   mem_co VARCHAR2(20) REFERENCES MEMBER(mem_co), -- 사용자 코드 
   title VARCHAR2(100), -- 이슈명
   important VARCHAR2(20), -- 이슈 중요도
   manager VARCHAR2(100), -- 조치자
   content VARCHAR2(2000), -- 내용
   ins_date DATE, -- 작성일
   name varchar2(20), -- 작성자
   no number, -- 페이지 번호
   refno number, -- 리플 번호
   issue_sts varchar2(20) -- 이슈 처리 현황
);

CREATE SEQUENCE iss_seq
	START WITH 1
	INCREMENT BY 1;

-- 이슈 첨부 파일

CREATE TABLE att_file (
	file_co   varchar2(20) PRIMARY KEY, -- 파일코드
	file_name varchar2(100), -- 파일명
	org_name  varchar2(100) -- 원본파일명
);

----------------------
-- 스케줄러

-- DROP TABLE scheduler;

CREATE TABLE scheduler(
	id NUMBER PRIMARY KEY,
	task_name varchar2(200),
	name varchar2(20),
	content varchar2(1000),
	pro_state varchar2(20),
	BEGIN2 varchar2(50),
	END2 varchar2(50),
	backgroundColor varchar2(10),
	textColor varchar2(10),
	allDay varchar2(1)
);
create sequence sche_seq
			minvalue 0
			maxvalue 99999
			increment by 1
			start with 0
			cache 20;
		
INSERT INTO scheduler VALUES(
	sche_seq.nextval,
	'회원 로그인',
	'서태웅',
	'회원 로그인 방식은 부여된 아이디와 비밀번호로 가능',
	'착수',
	'2019-11-20T09:00:00',
	'2019-11-21T09:00:00',
	'#0099cc',
	'#ccffff',
	''
);

SELECT * FROM scheduler;


INSERT INTO scheduler VALUES(
	sche_seq.nextval,
	'프로젝트 리스트 구현',
	'윤대협',
	'프로젝트 리스트를 구현하여 한 눈에 확인 가능하도록 함',
	'실행',
	'2019-11-20',
	'2019-11-23T09:00:00',
	'#0099cc',
	'#ccffff',
	''
);
INSERT INTO scheduler VALUES(
	sche_seq.nextval,
	'회원 로그아웃',
	'강백호',
	'로그아웃 할 수 있도록 처리',
	'실행',
	'2019-11-28T09:00:00',
	'2019-11-28T09:00:00',
	'#ccffff',
	'#0099cc',
	''
);

INSERT INTO scheduler VALUES(
	sche_seq.nextval,
	'스케쥴러 활용',
	'채치수',
	'스케쥴러를 활용하여 업무 일정을 공유할 수 있도록 함',
	'실행',
	'2019-11-18T09:00:00',
	'2019-11-21T17:00:00',
	'#ccffff',
	'#0099cc',
	''
);

INSERT INTO scheduler VALUES(
	sche_seq.nextval,
	'스케줄 삭제',
	'김삭제',
	'스케쥴러 데이터 삭제',
	'착수',
	'2019-11-20T09:00:00',
	'2019-11-21T10:00:00',
	'#ccffff',
	'#0099cc',
	''
);
