$(document).ready(function(){
	$(document).on('click','#profile2-tab',function(event){
		//alert("담당자"+event.target.href);
		//history.pushState -> ip에서만 가능
		history.pushState(null,null,event.target.href);
		$('article').load(event.target.href+ ' article>.content');
		//alert("excuted");
		event.preventDefault();
		$("#x").submit();
	})
	
	$(document).on('click','#person-tab',function(event){
		//alert("pm"+event.target.href);
		//history.pushState -> ip에서만 가능
		history.pushState(null,null,event.target.href);
		$('article').load(event.target.href+ ' article>.content');
		//alert("excuted");
		event.preventDefault();
		$("#y").submit();
	})
	
	//이건 됨
	$(window).on('popstate',function(event){
		$('article').load(location.href+ ' article>.content');
	})
	
	
	
});