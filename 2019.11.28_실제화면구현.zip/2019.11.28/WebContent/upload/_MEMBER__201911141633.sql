INSERT INTO SCOTT."MEMBER" (MEM_CO,MEM_SORT,ID,PASS,NAME,JOB,PHONE,EMAIL,PHOTO,ADMIN_CK) VALUES 
('M-00023','pm','admin','1234','홍길동','팀장','010-1234-5678','admin12@gmail.com',NULL,'1')
,('M-00024','member','worker','5678','노예','사원','010-2345-6789','worker34@naver.com',NULL,'0')
,('M-1','pm','agrahl32042','dhgaor294y','감우성','pm','010-5125-5481','agrahl32042@gmail.com',NULL,'0')
,('M-2','pm','afwenago324','hragaeh4545','김수로','팀장','010-5487-6568','afwenago324@gmail.com',NULL,'0')
,('M-3','pm','uykyuj6768','afragth542','노민환','팀장','010-5485-7811','uykyuj6768@gmail.com',NULL,'0')
,('M-4','pm','gsathj65656','agr4t34334','서상수','팀장','010-1245-7845','gsathj65656@gmail.com',NULL,'0')
,('M-5','member','hsgrg3443','shdsh5454','최태웅','팀장','010-7845-8954','hsgrg3443@gmail.com',NULL,'0')
,('M-6','member','hsgrg3443','ddsdds','최태웅','팀장','010-7845-8954','hsgrg3443@gmail.com',NULL,'0')
,('M-7','member','agrwhgr322','hssrgg34t53','이충헌','팀장','010-5412-5623','agrwhgr322@gmail.com',NULL,'0')
,('M-41','pm','sunsun1234','sun123qwe','김길동','팀장','02-999-8888','sunsun1234@daum.net','img0001.jpg','0')
;
INSERT INTO SCOTT."MEMBER" (MEM_CO,MEM_SORT,ID,PASS,NAME,JOB,PHONE,EMAIL,PHOTO,ADMIN_CK) VALUES 
('M-42','member','tayotayo','tayo1234','이길동','대리','02-988-7777','tayotayo@daum.net','img0002.jpg','0')
,('M-43','member','loooopy','lplp12','마길동','사원','010-5555-8888','loooopy@naver.com','img0003.jpg','0')
,('M-44','member','crooong','lslghel23','박길동','인턴','02-554-8569','crooong@daum.net','img0004.jpg','0')
,('M-45','member','eeedy99','12dheo23','최길동','대리','02-554-8457','eeedy99@daum.net','img0005.jpg','0')
,('M-46','member','bananacha','chacha124','장길동','대리','02-779-5587','bananacha@daum.net','img0006.jpg','0')
,('M-47','member','customer1','cus123','김철수','대리','032-345-2234','cs123@gmail.com','img0007.jpg','0')
;